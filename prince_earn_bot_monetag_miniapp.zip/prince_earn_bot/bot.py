import os
import sqlite3
import logging
from decimal import Decimal, InvalidOperation
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
MONETAG_URL = os.getenv("MONETAG_URL", "").strip()
MINI_APP_URL = os.getenv("MINI_APP_URL", "").strip()
DB_PATH = os.getenv("DB_PATH", "bot.db")
DEFAULT_REFERRAL_BONUS = Decimal(os.getenv("REFERRAL_BONUS", "0.10"))
DEFAULT_AD_REWARD = Decimal(os.getenv("AD_REWARD", "0.00"))
MIN_WITHDRAWAL = Decimal(os.getenv("MIN_WITHDRAWAL", "50.00"))
logging.basicConfig(level=logging.INFO)
log = logging.getLogger(__name__)

def db():
    conn = sqlite3.connect(DB_PATH, timeout=20)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS users (
          user_id INTEGER PRIMARY KEY, username TEXT, first_name TEXT,
          balance TEXT NOT NULL DEFAULT '0', referred_by INTEGER,
          joined_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS settings (
          key TEXT PRIMARY KEY, value TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS withdrawals (
          id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
          amount TEXT NOT NULL, method TEXT NOT NULL, account TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'pending',
          created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS ledger (
          id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
          amount TEXT NOT NULL, reason TEXT NOT NULL,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        """)
        c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('admin_id','')")
        c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('referral_bonus',?)",
                  (str(DEFAULT_REFERRAL_BONUS),))
        c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('ad_reward',?)",
                  (str(DEFAULT_AD_REWARD),))
        c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('min_withdrawal',?)",
                  (str(MIN_WITHDRAWAL),))
        c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('monetag_url',?)",
                  (MONETAG_URL,))

def setting(key):
    with db() as c:
        row = c.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row else ""

def set_setting(key, value):
    with db() as c:
        c.execute("INSERT INTO settings(key,value) VALUES(?,?) "
                  "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(value)))

def is_admin(uid):
    return setting("admin_id") == str(uid) and bool(setting("admin_id"))

def money(value):
    return f"{Decimal(str(value)):.2f}"

def main_keyboard():
    rows = [
        [InlineKeyboardButton("💰 আমার ব্যালেন্স", callback_data="balance"),
         InlineKeyboardButton("👥 রেফারেল", callback_data="referral")],
    ]
    if MINI_APP_URL.startswith("https://"):
        rows.append([InlineKeyboardButton("📺 বিজ্ঞাপন দেখুন", web_app=WebAppInfo(url=MINI_APP_URL))])
    else:
        rows.append([InlineKeyboardButton("📺 বিজ্ঞাপন", callback_data="ads")])
    rows.extend([
        [InlineKeyboardButton("💸 উইথড্র", callback_data="withdraw_help")],
        [InlineKeyboardButton("ℹ️ সাহায্য", callback_data="help")],
    ])
    return InlineKeyboardMarkup(rows)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = update.effective_user
    if not u:
        return
    referrer = None
    if context.args:
        try:
            candidate = int(context.args[0])
            if candidate != u.id:
                referrer = candidate
        except ValueError:
            pass
    with db() as c:
        existing = c.execute("SELECT user_id FROM users WHERE user_id=?", (u.id,)).fetchone()
        if not existing:
            valid_ref = c.execute("SELECT user_id FROM users WHERE user_id=?", (referrer,)).fetchone() if referrer else None
            referrer = referrer if valid_ref else None
            c.execute("INSERT INTO users(user_id,username,first_name,referred_by) VALUES(?,?,?,?)",
                      (u.id, u.username or "", u.first_name or "", referrer))
            if referrer:
                bonus = Decimal(setting("referral_bonus") or "0")
                row = c.execute("SELECT balance FROM users WHERE user_id=?", (referrer,)).fetchone()
                if row and bonus > 0:
                    new_balance = Decimal(row["balance"]) + bonus
                    c.execute("UPDATE users SET balance=? WHERE user_id=?", (money(new_balance), referrer))
                    c.execute("INSERT INTO ledger(user_id,amount,reason) VALUES(?,?,?)",
                              (referrer, money(bonus), f"Referral signup: {u.id}"))
    await update.message.reply_text(
        f"স্বাগতম, {u.first_name or 'বন্ধু'}! 🎉\n\n"
        "Prince Earn Bot-এ তোমার আয়, রেফারেল ও উইথড্র অপশন নিচে আছে।\n"
        "নোট: রেফারেল বোনাসের নিয়ম অ্যাডমিন পরিবর্তন করতে পারবেন।",
        reply_markup=main_keyboard()
    )

async def claim_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = update.effective_user
    current = setting("admin_id")
    if current:
        if current == str(u.id):
            await update.message.reply_text("তুমি ইতিমধ্যে অ্যাডমিন। /admin লিখে প্যানেল দেখো।")
        else:
            await update.message.reply_text("অ্যাডমিন ইতিমধ্যে সেট করা আছে। এই কমান্ড দিয়ে আর কেউ অ্যাডমিন হতে পারবে না।")
        return
    # Atomic claim: only the first successful claimant can become admin.
    with db() as c:
        c.execute("BEGIN IMMEDIATE")
        row = c.execute("SELECT value FROM settings WHERE key='admin_id'").fetchone()
        if row and row["value"]:
            won = row["value"] == str(u.id)
        else:
            c.execute("UPDATE settings SET value=? WHERE key='admin_id'", (str(u.id),))
            won = True
    if won:
        await update.message.reply_text(
            "✅ তুমি প্রথম অ্যাডমিন হিসেবে সেট হয়েছ!\n/admin দিয়ে অ্যাডমিন প্যানেল খোলো।\n"
            "নিরাপত্তা: বট চালু করার আগে private Telegram chat-এ /patul পাঠাও।"
        )
    else:
        await update.message.reply_text("অন্য একজন ইতিমধ্যে অ্যাডমিন হয়ে গেছেন।")

async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("⛔ এই প্যানেল শুধু অ্যাডমিনের জন্য।")
        return
    with db() as c:
        users = c.execute("SELECT COUNT(*) n FROM users").fetchone()["n"]
        balance = c.execute("SELECT COALESCE(SUM(CAST(balance AS REAL)),0) n FROM users").fetchone()["n"]
        pending = c.execute("SELECT COUNT(*) n FROM withdrawals WHERE status='pending'").fetchone()["n"]
    await update.message.reply_text(
        "🛡️ ADMIN PANEL\n\n"
        f"👥 মোট ইউজার: {users}\n"
        f"💰 ইউজার ব্যালেন্সের মোট: {balance:.2f}\n"
        f"🧾 Pending withdrawals: {pending}\n\n"
        "কমান্ড:\n"
        "/setref <amount> — নতুন রেফারেল বোনাস\n"
        "/setad <amount> — বিজ্ঞাপন রিওয়ার্ড সেট (শুধু যাচাইযোগ্য হলে ব্যবহার)\n"
        "/setmin <amount> — ন্যূনতম উইথড্র\n"
        "/setadlink <url> — Monetag লিংক সেট\n"
        "/withdrawals — pending রিকোয়েস্ট দেখো\n"
        "/approve <id> — রিকোয়েস্ট অনুমোদন\n"
        "/reject <id> — রিকোয়েস্ট বাতিল\n"
        "/users — ইউজার তালিকার সংক্ষিপ্ত তথ্য"
    )

async def set_amount(update, context, key, label):
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("⛔ অ্যাডমিন অনুমতি প্রয়োজন।"); return
    if len(context.args) != 1:
        await update.message.reply_text(f"ব্যবহার: /{key.replace('_','')} <amount>"); return
    try:
        amount = Decimal(context.args[0])
        if amount < 0 or amount > Decimal("1000000"):
            raise InvalidOperation
    except Exception:
        await update.message.reply_text("সঠিক ধনাত্মক সংখ্যা লিখো।"); return
    setting_key = {"referral_bonus":"referral_bonus","ad_reward":"ad_reward","min_withdrawal":"min_withdrawal"}[key]
    set_setting(setting_key, money(amount))
    await update.message.reply_text(f"✅ {label} সেট হয়েছে: {money(amount)}")

async def setref(update, context): await set_amount(update, context, "referral_bonus", "রেফারেল বোনাস")
async def setad(update, context): await set_amount(update, context, "ad_reward", "অ্যাড রিওয়ার্ড")
async def setmin(update, context): await set_amount(update, context, "min_withdrawal", "ন্যূনতম উইথড্র")

async def setadlink(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("⛔ অ্যাডমিন অনুমতি প্রয়োজন।"); return
    if not context.args or not context.args[0].startswith(("https://", "http://")):
        await update.message.reply_text("ব্যবহার: /setadlink https://your-monetag-link"); return
    set_setting("monetag_url", context.args[0])
    await update.message.reply_text("✅ বিজ্ঞাপনের লিংক সেভ হয়েছে।")

async def withdrawals(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("⛔ অ্যাডমিন অনুমতি প্রয়োজন।"); return
    with db() as c:
        rows = c.execute("SELECT * FROM withdrawals WHERE status='pending' ORDER BY id LIMIT 20").fetchall()
    if not rows:
        await update.message.reply_text("কোনো pending withdrawal নেই।"); return
    out = ["🧾 Pending withdrawals:"]
    for r in rows:
        out.append(f"ID {r['id']} | User {r['user_id']} | {r['amount']} | {r['method']} | {r['account']}")
    await update.message.reply_text("\n".join(out))

async def change_withdrawal(update: Update, context: ContextTypes.DEFAULT_TYPE, status):
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("⛔ অ্যাডমিন অনুমতি প্রয়োজন।"); return
    if len(context.args) != 1 or not context.args[0].isdigit():
        await update.message.reply_text("ব্যবহার: /approve <id> অথবা /reject <id>"); return
    wid = int(context.args[0])
    with db() as c:
        row = c.execute("SELECT * FROM withdrawals WHERE id=? AND status='pending'", (wid,)).fetchone()
        if not row:
            await update.message.reply_text("রিকোয়েস্ট পাওয়া যায়নি বা আগেই প্রসেস হয়েছে।"); return
        c.execute("UPDATE withdrawals SET status=? WHERE id=?", (status, wid))
        if status == "rejected":
            urow = c.execute("SELECT balance FROM users WHERE user_id=?", (row["user_id"],)).fetchone()
            new_balance = Decimal(urow["balance"]) + Decimal(row["amount"])
            c.execute("UPDATE users SET balance=? WHERE user_id=?", (money(new_balance), row["user_id"]))
            c.execute("INSERT INTO ledger(user_id,amount,reason) VALUES(?,?,?)",
                      (row["user_id"], row["amount"], f"Withdrawal refund #{wid}"))
    await update.message.reply_text(f"✅ Withdrawal #{wid}: {status}")

async def approve(update, context): await change_withdrawal(update, context, "approved")
async def reject(update, context): await change_withdrawal(update, context, "rejected")

async def users_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("⛔ অ্যাডমিন অনুমতি প্রয়োজন।"); return
    with db() as c:
        rows = c.execute("SELECT user_id,username,balance,referred_by FROM users ORDER BY joined_at DESC LIMIT 20").fetchall()
    await update.message.reply_text("সর্বশেষ ইউজার:\n" + "\n".join(
        f"{r['user_id']} @{r['username'] or '-'} | balance {r['balance']} | ref {r['referred_by'] or '-'}" for r in rows
    ))

async def withdraw(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = update.effective_user
    if len(context.args) < 3:
        await update.message.reply_text(
            "উইথড্র রিকোয়েস্টের ফরম্যাট:\n/withdraw <amount> <bkash|nagad> <account-number>\n"
            "উদাহরণ: /withdraw 100 bkash 01XXXXXXXXX"
        ); return
    try:
        amount = Decimal(context.args[0])
        method = context.args[1].lower()
        account = context.args[2]
        minimum = Decimal(setting("min_withdrawal") or "50")
        if amount <= 0 or method not in ("bkash", "nagad") or len(account) < 8:
            raise ValueError()
    except Exception:
        await update.message.reply_text("তথ্য ঠিক নয়। amount, bkash/nagad এবং অ্যাকাউন্ট নম্বর পরীক্ষা করো।"); return
    with db() as c:
        c.execute("BEGIN IMMEDIATE")
        row = c.execute("SELECT balance FROM users WHERE user_id=?", (u.id,)).fetchone()
        if not row:
            await update.message.reply_text("আগে /start পাঠাও।"); return
        balance = Decimal(row["balance"])
        if amount < minimum:
            await update.message.reply_text(f"ন্যূনতম উইথড্র {money(minimum)}।"); return
        if amount > balance:
            await update.message.reply_text(f"তোমার ব্যালেন্স {money(balance)}; এত টাকা নেই।"); return
        c.execute("UPDATE users SET balance=? WHERE user_id=?", (money(balance-amount), u.id))
        c.execute("INSERT INTO withdrawals(user_id,amount,method,account) VALUES(?,?,?,?)",
                  (u.id, money(amount), method, account))
        c.execute("INSERT INTO ledger(user_id,amount,reason) VALUES(?,?,?)",
                  (u.id, money(-amount), "Withdrawal requested"))
    await update.message.reply_text("✅ উইথড্র রিকোয়েস্ট জমা হয়েছে। অ্যাডমিন যাচাই করে প্রসেস করবেন।")

async def buttons(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    uid = q.from_user.id
    if q.data == "balance":
        with db() as c:
            row = c.execute("SELECT balance FROM users WHERE user_id=?", (uid,)).fetchone()
            earnings = c.execute("SELECT COALESCE(SUM(CAST(amount AS REAL)),0) n FROM ledger WHERE user_id=? AND CAST(amount AS REAL)>0", (uid,)).fetchone()["n"]
        await q.message.reply_text(f"💰 বর্তমান ব্যালেন্স: {row['balance'] if row else '0.00'}\n📈 মোট positive entries: {earnings:.2f}")
    elif q.data == "referral":
        bot = await context.bot.get_me()
        with db() as c:
            count = c.execute("SELECT COUNT(*) n FROM users WHERE referred_by=?", (uid,)).fetchone()["n"]
        await q.message.reply_text(f"👥 তোমার রেফারেল: {count}\n\nতোমার লিংক:\nhttps://t.me/{bot.username}?start={uid}\n\nনতুন ইউজার প্রথমবার এই লিংক দিয়ে /start করলে রেফারেল বোনাস যোগ হবে।")
    elif q.data == "ads":
        url = setting("monetag_url")
        if url:
            await q.message.reply_text("📺 বিজ্ঞাপনের লিংক নিচে। প্রকৃত বিজ্ঞাপন-আয় Monetag-এর ড্যাশবোর্ডে যাচাই করো।",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("বিজ্ঞাপন খুলুন", url=url)]]))
        else:
            await q.message.reply_text("এখনো বিজ্ঞাপনের লিংক সেট করা হয়নি।")
    elif q.data == "withdraw_help":
        await q.message.reply_text("উইথড্র রিকোয়েস্ট:\n/withdraw <amount> <bkash|nagad> <account-number>\n\nউদাহরণ: /withdraw 100 bkash 01XXXXXXXXX")
    else:
        await q.message.reply_text("কমান্ড: /start, /withdraw, /help\nঅ্যাডমিন হলে /admin।")

async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "ব্যবহার:\n/start — বট চালু\n/patul — প্রথম অ্যাডমিন দাবি\n/admin — অ্যাডমিন প্যানেল\n"
        "/withdraw <amount> <bkash|nagad> <account-number> — উইথড্র রিকোয়েস্ট\n\n"
        "সতর্কতা: রেফারেল বোনাস কেবল নতুন ইউজারের প্রথম /start-এ যোগ হয়। "
        "Monetag ad views/clicks এই বট নিজে যাচাই করতে পারে না।"
    )

def main():
    if not BOT_TOKEN:
        raise SystemExit("BOT_TOKEN সেট করা নেই। .env.example দেখুন এবং environment variable দিন।")
    init_db()
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("patul", claim_admin))
    app.add_handler(CommandHandler("admin", admin_panel))
    app.add_handler(CommandHandler("setref", setref))
    app.add_handler(CommandHandler("setad", setad))
    app.add_handler(CommandHandler("setmin", setmin))
    app.add_handler(CommandHandler("setadlink", setadlink))
    app.add_handler(CommandHandler("withdrawals", withdrawals))
    app.add_handler(CommandHandler("approve", approve))
    app.add_handler(CommandHandler("reject", reject))
    app.add_handler(CommandHandler("users", users_cmd))
    app.add_handler(CommandHandler("withdraw", withdraw))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(CallbackQueryHandler(buttons))
    log.info("Prince Earn Bot starting")
    app.run_polling(stop_signals=[])

if __name__ == "__main__":
    main()
