# Prince Earn Bot + Monetag Telegram Mini App

This starter includes the Telegram bot, a Telegram Mini App (`index.html`), and a Flask backend that receives Monetag postbacks. The Mini App uses the supplied main SDK zone ID `12084036` and loads the tag:

```html
<script src="https://libtl.com/sdk.js" data-zone="12084036" data-sdk="show_12084036"></script>
```

## Important: not fully live until configured

- This code cannot verify that your Monetag zone is approved or that ads will fill on your account. Test only after the Mini App is added/approved in Monetag.
- The server grants an ad reward only after a valid-secret Monetag postback says `reward_event_type=valued`, checks the zone and `ymid`, and processes each `ymid` once. A frontend callback alone never credits money.
- The Telegram bot and Flask web app must share the same persistent `DB_PATH` file. `run.py` starts both in one service for this starter. If your host separates web/worker services or has ephemeral storage, move to a shared managed database before launch.
- This starter validates Telegram Mini App `initData`; users should first send `/start` to the bot. Use HTTPS in production.
- `/patul` lets the first claimant become admin. Claim it privately before sharing the bot, or replace it with a fixed admin ID for production.
- Withdrawals are manually reviewed. Do not promise income or encourage ad clicks; users should only view ads voluntarily and follow Monetag's policies.

## Environment variables

Copy `.env.example` values into your hosting provider's environment settings (do not upload real secrets):

- `BOT_TOKEN`: Telegram bot token from BotFather
- `MONETAG_ZONE_ID=12084036`: main SDK zone ID
- `MONETAG_POSTBACK_SECRET`: long random secret, same value used in Monetag's postback URL
- `MINI_APP_URL`: public HTTPS URL for this app, for example your deployed app root
- `DB_PATH=bot.db`: persistent database path
- `AD_REWARD`: initial default only. The database setting can be changed with `/setad 0.10` (example amount; choose a value you can afford and that complies with your Monetag terms).
- `PORT`: host-provided port, usually set automatically

## Deploy on an HTTPS Python host

1. Upload these project files to a Python web service that supports a persistent disk or mount. Start command: `python run.py` (Procfile is included for compatible hosts).
2. Add the environment variables above. Generate a strong `MONETAG_POSTBACK_SECRET`; do not share it in chat or commit it to GitHub.
3. Once the app is live at `https://YOUR-DOMAIN/`, set `MINI_APP_URL=https://YOUR-DOMAIN/` and redeploy/restart.
4. In Telegram, send `/start` to your bot, then privately send `/patul` to claim admin if not already claimed. Set a small test reward with `/setad 0.10` only after you decide the economics. `/setad` changes the app's database setting.
5. In Monetag, open the main SDK zone's Postback URL setting and paste this URL, replacing the domain and secret with your real values:

   ```text
   https://YOUR-DOMAIN/postback?secret=YOUR_LONG_RANDOM_SECRET&ymid={ymid}&zone_id={zone_id}&event_type={event_type}&reward_event_type={reward_event_type}&estimated_price={estimated_price}&telegram_id={telegram_id}
   ```

6. Save the postback URL in Monetag. Make sure the Mini App is registered/approved there and the main zone ID is `12084036`.
7. In BotFather, configure the Mini App menu button to the same HTTPS URL if needed. The bot's `/start` keyboard also shows a Web App button when `MINI_APP_URL` is set to an HTTPS URL.
8. Test with your own account and check the host logs. A reward is granted only for a `valued` postback. `non_valued` events are ignored. Duplicate postbacks for the same `ymid` do not pay twice.

## Test endpoints

- `GET /health` should return `{"ok": true, ...}`.
- `GET /` should show the Mini App page.
- `GET /postback` without the secret should return HTTP 403. This is expected.

## GitHub safety

Do not commit `.env`, the bot token, postback secret, `bot.db`, user records, or payment details. `.gitignore` excludes local secrets and databases.
