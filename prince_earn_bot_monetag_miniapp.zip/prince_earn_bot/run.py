"""Run the Telegram bot and HTTPS web app in one service so they share SQLite."""
import os
import threading
import time

import bot
import app as webapp


def run_bot():
    bot.main()

if __name__ == "__main__":
    if not os.getenv("BOT_TOKEN", "").strip():
        raise SystemExit("BOT_TOKEN is required")
    bot.init_db()
    webapp.init_ad_tables()
    threading.Thread(target=run_bot, name="telegram-bot", daemon=True).start()
    port = int(os.getenv("PORT", "8080"))
    webapp.app.run(host="0.0.0.0", port=port, threaded=True)
