import hashlib
import hmac
import json
import os
import re
import sqlite3
import time
import uuid
from decimal import Decimal, InvalidOperation
from urllib.parse import parse_qsl

from flask import Flask, jsonify, request, send_from_directory

app = Flask(__name__, static_folder=".", static_url_path="")
BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
DB_PATH = os.getenv("DB_PATH", "bot.db")
ZONE_ID = os.getenv("MONETAG_ZONE_ID", "12084036").strip()
POSTBACK_SECRET = os.getenv("MONETAG_POSTBACK_SECRET", "").strip()


def db():
    conn = sqlite3.connect(DB_PATH, timeout=20)
    conn.row_factory = sqlite3.Row
    return conn


def init_ad_tables():
    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS pending_ads (
            ymid TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL,
            created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS rewarded_ads (
            ymid TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL,
            zone_id TEXT NOT NULL,
            event_type TEXT NOT NULL,
            estimated_price TEXT NOT NULL DEFAULT '0',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        """)


def validate_init_data(init_data: str):
    """Validate Telegram WebApp initData using Telegram's documented HMAC scheme."""
    if not BOT_TOKEN or not init_data or len(init_data) > 10000:
        return None
    try:
        pairs = dict(parse_qsl(init_data, keep_blank_values=True, strict_parsing=True))
        received_hash = pairs.pop("hash", "")
        auth_date = int(pairs.get("auth_date", "0"))
        if not received_hash or time.time() - auth_date > 86400 or auth_date > time.time() + 60:
            return None
        data_check_string = "\n".join(f"{k}={v}" for k, v in sorted(pairs.items()))
        secret_key = hmac.new(BOT_TOKEN.encode(), b"WebAppData", hashlib.sha256).digest()
        calculated = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(calculated, received_hash):
            return None
        user = json.loads(pairs.get("user", "{}"))
        user_id = int(user.get("id", 0))
        return user_id if user_id > 0 else None
    except (ValueError, TypeError, json.JSONDecodeError):
        return None


def ensure_user(user_id):
    with db() as c:
        return c.execute("SELECT user_id FROM users WHERE user_id=?", (user_id,)).fetchone() is not None


@app.get("/")
def index():
    return send_from_directory(".", "index.html")


@app.get("/health")
def health():
    return jsonify({"ok": True, "service": "Prince Earn Bot Mini App"}), 200


@app.post("/api/ad-session")
def create_ad_session():
    data = request.get_json(silent=True) or {}
    user_id = validate_init_data(str(data.get("initData", "")))
    if not user_id:
        return jsonify({"ok": False, "error": "Telegram যাচাই ব্যর্থ। Mini App-টি Telegram-এর ভিতর থেকে খোলো।"}), 401
    if not ensure_user(user_id):
        return jsonify({"ok": False, "error": "আগে Telegram বটে /start পাঠাও, তারপর বিজ্ঞাপন দেখো।"}), 403
    ymid = f"u{user_id}_{uuid.uuid4().hex}"
    with db() as c:
        c.execute("INSERT INTO pending_ads(ymid,user_id,created_at) VALUES(?,?,?)", (ymid, user_id, int(time.time())))
    return jsonify({"ok": True, "ymid": ymid}), 200


@app.get("/api/ad-status")
def ad_status():
    user_id = validate_init_data(request.args.get("initData", ""))
    ymid = request.args.get("ymid", "")
    if not user_id:
        return jsonify({"ok": False, "error": "Telegram যাচাই ব্যর্থ।"}), 401
    with db() as c:
        pending = c.execute("SELECT user_id FROM pending_ads WHERE ymid=?", (ymid,)).fetchone()
        if not pending or int(pending["user_id"]) != user_id:
            return jsonify({"ok": False, "error": "এই বিজ্ঞাপন সেশনটি পাওয়া যায়নি।"}), 404
        reward = c.execute("SELECT 1 FROM rewarded_ads WHERE ymid=? AND user_id=?", (ymid, user_id)).fetchone()
        user = c.execute("SELECT balance FROM users WHERE user_id=?", (user_id,)).fetchone()
    return jsonify({"ok": True, "rewarded": bool(reward), "balance": user["balance"] if user else "0.00"}), 200


@app.get("/postback")
def monetag_postback():
    # Monetag calls this endpoint from its server; never reward from the browser callback.
    if not POSTBACK_SECRET or not hmac.compare_digest(request.args.get("secret", ""), POSTBACK_SECRET):
        return "Forbidden", 403
    ymid = request.args.get("ymid", "")
    zone_id = request.args.get("zone_id", "")
    reward_event_type = request.args.get("reward_event_type", "")
    event_type = request.args.get("event_type", "")
    telegram_id = request.args.get("telegram_id", "")
    estimated_price = request.args.get("estimated_price", "0")

    if not re.fullmatch(r"[A-Za-z0-9_.-]{1,180}", ymid):
        return "Bad ymid", 400
    if zone_id != ZONE_ID:
        return "Wrong zone", 403
    if event_type not in ("impression", "click"):
        return "Ignored event", 200
    if reward_event_type != "valued":
        return "Non-valued event ignored", 200
    try:
        price = Decimal(estimated_price)
        if not price.is_finite() or price < 0:
            price = Decimal("0")
    except InvalidOperation:
        price = Decimal("0")

    with db() as c:
        pending = c.execute("SELECT user_id FROM pending_ads WHERE ymid=?", (ymid,)).fetchone()
        if not pending:
            # An unknown ymid must never create a balance credit.
            return "Unknown ymid", 404
        user_id = int(pending["user_id"])
        if telegram_id and telegram_id.isdigit() and int(telegram_id) != user_id:
            return "Telegram ID mismatch", 403
        existing = c.execute("SELECT 1 FROM rewarded_ads WHERE ymid=?", (ymid,)).fetchone()
        if existing:
            return "Already processed", 200
        user = c.execute("SELECT balance FROM users WHERE user_id=?", (user_id,)).fetchone()
        if not user:
            return "Unknown user", 404
        settings = c.execute("SELECT value FROM settings WHERE key='ad_reward'").fetchone()
        try:
            reward = Decimal(settings["value"] if settings else "0")
            if not reward.is_finite() or reward <= 0:
                reward = Decimal("0")
        except InvalidOperation:
            reward = Decimal("0")
        c.execute("INSERT INTO rewarded_ads(ymid,user_id,zone_id,event_type,estimated_price) VALUES(?,?,?,?,?)",
                  (ymid, user_id, zone_id, event_type, str(price)))
        if reward > 0:
            balance = Decimal(user["balance"] or "0") + reward
            c.execute("UPDATE users SET balance=? WHERE user_id=?", (f"{balance:.2f}", user_id))
            c.execute("INSERT INTO ledger(user_id,amount,reason) VALUES(?,?,?)",
                      (user_id, f"{reward:.2f}", f"Monetag valued ad: {ymid}"))
    return "OK", 200


if __name__ == "__main__":
    init_ad_tables()
    port = int(os.getenv("PORT", "8080"))
    app.run(host="0.0.0.0", port=port)
